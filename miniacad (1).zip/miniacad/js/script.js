// Manejo accesible para mini-quizzes
document.addEventListener('DOMContentLoaded', () => {
  const quizForms = document.querySelectorAll('.quiz-form');

  quizForms.forEach(form => {
    form.addEventListener('submit', (e) => {
      e.preventDefault();
      const selected = form.querySelector('input[type="radio"]:checked');
      const feedback = form.querySelector('.quiz-feedback');

      if (!selected) {
        feedback.textContent = 'Por favor, selecciona una respuesta antes de enviar.';
        feedback.style.color = '#b71c1c';
        return;
      }

      if (selected.value === 'correcto') {
        feedback.textContent = '¡Excelente trabajo! Tu respuesta es correcta. 🎉';
        feedback.style.color = '#1b5e20';
      } else {
        feedback.textContent = 'Inténtalo de nuevo. ¡Tú puedes lograrlo!';
        feedback.style.color = '#b71c1c';
      }
    });
  });
});